package com.cg.bootcamp.obs;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;
import com.cg.bootcamp.obs.dto.Customer;
import com.cg.bootcamp.obs.dto.Orders;
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
class OnlineBookStoreApplicationTests {

	@Autowired
	TestRestTemplate testRestTemplate;
	public void setTestRestTemplate(TestRestTemplate testRestTemplate)
	{
		this.testRestTemplate=testRestTemplate;
	}
	
	@LocalServerPort
	int localServerPort;
	
	@Test
	public void testgetCustomerOrderHistory_Positive() throws Exception
	{
		 String url="http://localhost:"+localServerPort+"getCustomerOrderHistory/145";
		 ResponseEntity<Customer> customer = testRestTemplate.getForEntity(url,Customer.class);
		 Assertions.assertEquals(200, customer.getStatusCodeValue());
	}
	
	@Test
	public void testgetCustomerOrderHistory_Negative() throws Exception
	{
		 String url="http://localhost:"+localServerPort+"getCustomerOrderHistory/152";
		 ResponseEntity<Customer> customer = testRestTemplate.getForEntity(url,Customer.class);
		 Assertions.assertNotEquals(200, customer.getStatusCodeValue());
	}
	
	@Test
	public void testgetOrderHistoryByEmailId_Positive() throws Exception
	{
		 String url="http://localhost:"+localServerPort+"getOrderHistoryBy/email/kopojjukavya@gmail.com";
		 ResponseEntity<Customer> customer = testRestTemplate.getForEntity(url,Customer.class);
		 Assertions.assertEquals(200, customer.getStatusCodeValue());
	}
	
	@Test
	public void testgetOrderHistoryByEmailId_Negative() throws Exception
	{
		 String url="http://localhost:"+localServerPort+"getOrderHistoryBy/email/epuri.usha@gmail.com";
		 ResponseEntity<Customer> customer = testRestTemplate.getForEntity(url,Customer.class);
		 Assertions.assertNotEquals(200, customer.getStatusCodeValue());
	}
	
	@Test
	public void testgetOrderDetailsById_Positive() throws Exception
	{
		 String url="http://localhost:"+localServerPort+"getOrderDetailsById/32331";
		 ResponseEntity<Orders> order = testRestTemplate.getForEntity(url,Orders.class);
		 Assertions.assertEquals(200, order.getStatusCodeValue());
	}
	
	@Test
	public void testgetOrderDetailsById_Negative() throws Exception
	{
		 String url="http://localhost:"+localServerPort+"getOrderDetailsById/112233";
		 ResponseEntity<Orders> order = testRestTemplate.getForEntity(url,Orders.class);
		 Assertions.assertNotEquals(200, order.getStatusCodeValue());
	}
	
	
}
