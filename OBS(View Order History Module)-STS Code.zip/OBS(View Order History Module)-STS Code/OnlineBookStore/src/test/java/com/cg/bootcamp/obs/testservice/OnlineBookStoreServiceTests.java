package com.cg.bootcamp.obs.testservice;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.cg.bootcamp.obs.dto.Customer;
import com.cg.bootcamp.obs.dto.Orders;
import com.cg.bootcamp.obs.service.CustomerService;
import com.cg.bootcamp.obs.service.OrdersService;
@SpringBootTest
public class OnlineBookStoreServiceTests 
{
 @Autowired
 CustomerService customerService;
 
 @Autowired
 OrdersService ordersService;
 
 @Test
 public void testgetCustomerOrderHistory_Positive() throws Exception
 {
	    Optional<Customer> customer = customerService.getCustomerOrderHistory(121);
	    Assertions.assertEquals(true,customer.isPresent());
 }
 
 @Test
 public void testgetCustomerOrderHistory_Negative() throws Exception
 {
	    Optional<Customer> customer = customerService.getCustomerOrderHistory(222);
	    Assertions.assertEquals(false,customer.isPresent());
 }
 
 @Test
 public void testgetOrderHistoryByEmailId_Positive() throws Exception
 {
	    Optional<Customer> customer = customerService.getOrderHistoryByEmailId("Sreecharan0311@gmail.com");
	    Assertions.assertEquals(true,customer.isPresent());
 }
 
 @Test
 public void testgetOrderHistoryByEmailId_Negative() throws Exception
 {
	    Optional<Customer> customer = customerService.getOrderHistoryByEmailId("ManjariVaka.22@gmail.com");
	    Assertions.assertEquals(false,customer.isPresent());
 }
 
 @Test
 public void testgetOrderDetailsById_Positive() throws Exception
 {
	    Optional<Orders> order = ordersService.getOrderDetailsById(32396);
	    Assertions.assertEquals(true,order.isPresent());
 }
 
 @Test
 public void testgetOrderDetailsById_Negative() throws Exception
 {
	    Optional<Orders> order = ordersService.getOrderDetailsById(75561);
	    Assertions.assertEquals(false,order.isPresent());
 }
 
}
