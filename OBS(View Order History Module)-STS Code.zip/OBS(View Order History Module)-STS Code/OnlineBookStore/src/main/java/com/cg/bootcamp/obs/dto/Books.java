package com.cg.bootcamp.obs.dto;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="Books")
public class Books 
{
  @Id
  @Column(name="bookid")
  private int bookId;
  @Column(name="title")
  private String title;
  @Column(name="author")
  private String author;
  @Column(name="description")
  private String description;
  @Column(name="isbn")
  private String isbn;
  @Column(name="price")
  private float price;
  @Column(name="stock")
  private String stock;
  @OneToMany(cascade=CascadeType.ALL)
  @JoinColumn(name="bookid")
  private List<Category> category;
  public Books() {}
  
public Books(int bookId, String title, String author, String description, String isbn, float price, String stock,
		List<Category> category) {
	super();
	this.bookId = bookId;
	this.title = title;
	this.author = author;
	this.description = description;
	this.isbn = isbn;
	this.price = price;
	this.stock = stock;
	this.category = category;
}

public int getBookId() {
	return bookId;
}

public void setBookId(int bookId) {
	this.bookId = bookId;
}

public String getTitle() {
	return title;
}

public void setTitle(String title) {
	this.title = title;
}

public String getAuthor() {
	return author;
}

public void setAuthor(String author) {
	this.author = author;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

public String getIsbn() {
	return isbn;
}

public void setIsbn(String isbn) {
	this.isbn = isbn;
}

public float getPrice() {
	return price;
}

public void setPrice(float price) {
	this.price = price;
}

public String getStock() {
	return stock;
}

public void setStock(String stock) {
	this.stock = stock;
}

public List<Category> getCategory() {
	return category;
}

public void setCategory(List<Category> category) {
	this.category = category;
}


}