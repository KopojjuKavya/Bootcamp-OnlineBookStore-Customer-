package com.cg.bootcamp.obs.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.bootcamp.obs.dto.Orders;
@Repository
public interface OrdersDao extends JpaRepository<Orders, Integer> 
{

}