package com.cg.bootcamp.obs.service;
//import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bootcamp.obs.dao.CustomerDao;
import com.cg.bootcamp.obs.dto.Customer;
@Service
public class CustomerService 
{	
	@Autowired
    CustomerDao cdao;
    public void setCdao( CustomerDao cdao) { this.cdao=cdao;}
    
   /* @Transactional(readOnly=true)
    public List<Customer> getCustomers()
    {
    	return cdao.findAll();
    } */
    
    @Transactional(readOnly=true)
    public Optional<Customer> getCustomerOrderHistory(int customerId)
    {
    	return cdao.findById(customerId);
    }
    
    @Transactional(readOnly=true)
	public Optional<Customer> getOrderHistoryByEmailId(String email)
	{
		return cdao.findOrderHistoryByEmailId(email);
	}
}
