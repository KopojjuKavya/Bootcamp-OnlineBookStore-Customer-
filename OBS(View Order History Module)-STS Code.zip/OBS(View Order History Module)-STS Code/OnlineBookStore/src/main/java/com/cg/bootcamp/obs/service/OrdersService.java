package com.cg.bootcamp.obs.service;
//import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bootcamp.obs.dao.OrdersDao;
import com.cg.bootcamp.obs.dto.Orders;
@Service
public class OrdersService 
{
 @Autowired
 OrdersDao odao;
 public void setOdao(OrdersDao odao)
 {
	 this.odao=odao;
 }
 
 /*@Transactional(readOnly=true)
 public List<Orders> getOrders()
 {
	 return odao.findAll();
 }*/
 
 @Transactional(readOnly=true)
 public Optional<Orders> getOrderDetailsById(int orderId)
 {
 	return odao.findById(orderId);
 }
}
