package com.cg.bootcamp.obs.controller;
//import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bootcamp.obs.dto.Orders;
import com.cg.bootcamp.obs.exception.RecordNotFoundException;
import com.cg.bootcamp.obs.service.OrdersService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class OrdersController 
{
	@Autowired
	OrdersService ordersService;
	public void setOrdersService(OrdersService ordersService)
	{
		this.ordersService=ordersService;
	}
	
	private static final Logger LOGGER = LoggerFactory.getLogger(OrdersController.class);
	
	/* @GetMapping("/getOrders")
	   public List<Orders> getOrders()
	   {
		   return ordersService.getOrders();
	   } */
	 
	 @GetMapping(value="/getOrderDetailsById/{orderId}", produces="application/json")
	  public ResponseEntity<Optional<Orders>> getOrderDetailsById(@PathVariable int orderId)
	  {
		   Optional<Orders> order = ordersService.getOrderDetailsById(orderId);
		   LOGGER.warn("Request {} ", orderId);
		   if(order.isPresent())
			   return new ResponseEntity<Optional<Orders>>(order,HttpStatus.OK);
		   //return new ResponseEntity<Optional<Orders>>(order,HttpStatus.NOT_FOUND);
		   throw new RecordNotFoundException("Please check and enter a valid orderId!");
	  }
}

