package com.cg.bootcamp.obs.dto;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
//import com.fasterxml.jackson.annotation.JsonIdentityInfo;
//import com.fasterxml.jackson.annotation.ObjectIdGenerators;
@Entity
//@JsonIdentityInfo(generator=ObjectIdGenerators.PropertyGenerator.class,property="customerId")
@Table(name="Customer")
public class Customer
{
	@Id
	@Column(name = "customerid")
	private Integer customerId;
	@Column(name = "password")
	private String password;
	@Column(name = "fullname")
	private String fullName;
	@Column(name = "email")
	private String email;
	@Column(name = "phoneno")
	private String phoneNo;
	@Column(name = "address")
	private String address;
	@Column(name = "country")
	private String country;
	@Column(name = "pincode")
	private Integer pinCode;
	//@OneToMany(mappedBy="customer")
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="customerid")
	private List<Orders> orders;
	
	public Customer() {}

	public Customer(Integer customerId, String password, String fullName, String email, String phoneNo, String address,
			String country, Integer pinCode, List<Orders> orders) {
		super();
		this.customerId = customerId;
		this.password = password;
		this.fullName = fullName;
		this.email = email;
		this.phoneNo = phoneNo;
		this.address = address;
		this.country = country;
		this.pinCode = pinCode;
		this.orders = orders;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Integer getPinCode() {
		return pinCode;
	}

	public void setPinCode(Integer pinCode) {
		this.pinCode = pinCode;
	}

	public List<Orders> getOrders() {
		return orders;
	}

	public void setOrders(List<Orders> orders) {
		this.orders = orders;
	}

}