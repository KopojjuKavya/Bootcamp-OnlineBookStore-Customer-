package com.cg.bootcamp.obs.controller;
//import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.cg.bootcamp.obs.dto.Customer;
import com.cg.bootcamp.obs.exception.RecordNotFoundException;
import com.cg.bootcamp.obs.service.CustomerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class CustomerController
{
	@Autowired
	CustomerService customerService;
	public void setCustomerService(CustomerService customerService)
	{
		this.customerService=customerService;
	}
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CustomerController.class);

	
	 /*@GetMapping("/getCustomers")
	   public List<Customer> getCustomers()
	   {
		   return customerService.getCustomers();
	   }*/
	 
	 @GetMapping(value="/getCustomerOrderHistory/{customerId}", produces="application/json")
	  public ResponseEntity<Optional<Customer>> getCustomerOrderHistory(@PathVariable int customerId)
	  {
		   Optional<Customer> customer = customerService.getCustomerOrderHistory(customerId);
		   LOGGER.warn("Request {} ", customerId);
		   if(customer.isPresent())
			 return new ResponseEntity<Optional<Customer>>(customer,HttpStatus.OK);
		   //return new ResponseEntity<Optional<Customer>>(customer,HttpStatus.NOT_FOUND);
		   throw new RecordNotFoundException("Invalid customer Id! Please try again..");
	  }
	 
	 @GetMapping(value="/getOrderHistoryBy/email/{email}",produces="application/json")
	 public ResponseEntity<Optional<Customer>> getOrderHistoryByEmailId(@PathVariable String email)
	 {
		 Optional<Customer> customer =  customerService.getOrderHistoryByEmailId(email);
		 LOGGER.warn("Request {} ", email);
		 if(customer.isPresent())
			 return new ResponseEntity<Optional<Customer>>(customer,HttpStatus.OK);
		   //return new ResponseEntity<Optional<Customer>>(customer,HttpStatus.NOT_FOUND);
		 throw new RecordNotFoundException("Invalid email! Enter a vaild one..");
	 }
	 
}