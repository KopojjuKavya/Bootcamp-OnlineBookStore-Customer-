package com.cg.bootcamp.obs.dto;
import java.time.LocalDate;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
//import com.fasterxml.jackson.annotation.JsonIdentityInfo;
//import com.fasterxml.jackson.annotation.ObjectIdGenerators;
@Entity
//@JsonIdentityInfo(generator=ObjectIdGenerators.PropertyGenerator.class,property="orderId")
@Table(name="Orders")
public class Orders
{
 @Id
 @Column(name="orderid")
 private int orderId;
 @Column(name="quantity")
 private int quantity;
 @Column(name="total")
 private float total;
 @Column(name="paymentmethod")
 private String paymentMethod;
 @Column(name="dateoforder")
 private LocalDate dateOfOrder;
 /*@ManyToOne
 @JoinColumn(name="customerid")
 private Customer customer;*/
 //@OneToMany(mappedBy="orders")
 @OneToMany(cascade=CascadeType.ALL)
 @JoinColumn(name="orderid")
 private List<Books> books;
 public Orders() {}
public Orders(int orderId, int quantity, float total, String paymentMethod, LocalDate dateOfOrder, List<Books> books) {
	super();
	this.orderId = orderId;
	this.quantity = quantity;
	this.total = total;
	this.paymentMethod = paymentMethod;
	this.dateOfOrder = dateOfOrder;
	this.books = books;
}
public int getOrderId() {
	return orderId;
}
public void setOrderId(int orderId) {
	this.orderId = orderId;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public float getTotal() {
	return total;
}
public void setTotal(float total) {
	this.total = total;
}
public String getPaymentMethod() {
	return paymentMethod;
}
public void setPaymentMethod(String paymentMethod) {
	this.paymentMethod = paymentMethod;
}
public LocalDate getDateOfOrder() {
	return dateOfOrder;
}
public void setDateOfOrder(LocalDate dateOfOrder) {
	this.dateOfOrder = dateOfOrder;
}
public List<Books> getBooks() {
	return books;
}
public void setBooks(List<Books> books) {
	this.books = books;
}
}